package com.example.calculatorapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import net.objecthunter.exp4j.ExpressionBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var display: TextView

    // To track if last pressed button was '=' to reset display on next number input
    private var lastPressedEquals = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Change if your XML filename is different

        display = findViewById(R.id.display)

        val buttonIds = listOf(
            R.id.btn_off, R.id.btn_clear, R.id.btn_percent, R.id.btn_divide,
            R.id.btn_7, R.id.btn_8, R.id.btn_9, R.id.btn_multiply,
            R.id.btn_4, R.id.btn_5, R.id.btn_6, R.id.btn_minus,
            R.id.btn_1, R.id.btn_2, R.id.btn_3, R.id.btn_plus,
            R.id.btn_0, R.id.btn_dot, R.id.btn_equals, R.id.btn_delete
        )

        buttonIds.forEach { id ->
            findViewById<Button>(id).setOnClickListener { onButtonClick(it as Button) }
        }
    }

    private fun onButtonClick(button: Button) {
        val text = button.text.toString()

        when (text) {
            "OFF" -> {
                finish() // Close app
            }
            "C" -> {
                display.text = "0"
            }
            "del" -> {
                val currentText = display.text.toString()
                if (currentText.length > 1) {
                    display.text = currentText.dropLast(1)
                } else {
                    display.text = "0"
                }
            }
            "=" -> {
                calculateResult()
            }
            "%" -> {
                calculatePercentage()
            }
            else -> {
                // Append number or operator
                if (lastPressedEquals) {
                    // Reset after equals if input is number or dot
                    if (text.matches(Regex("[0-9.]"))) {
                        display.text = ""
                    }
                    lastPressedEquals = false
                }
                appendToDisplay(text)
            }
        }
    }

    private fun appendToDisplay(text: String) {
        val currentText = display.text.toString()

        if (currentText == "0" && text.matches(Regex("[0-9]"))) {
            // Replace leading 0 with number
            display.text = text
        } else {
            // Convert some symbols for expression parsing
            val newText = when (text) {
                "×" -> "*"
                "÷" -> "/"
                "−" -> "-"
                else -> text
            }
            display.append(newText)
        }
    }

    private fun calculateResult() {
        val expressionText = display.text.toString()
        try {
            val expression = ExpressionBuilder(expressionText).build()
            val result = expression.evaluate()

            // Show result removing .0 for integers
            val resultText = if (result % 1.0 == 0.0) {
                result.toLong().toString()
            } else {
                result.toString()
            }
            display.text = resultText
            lastPressedEquals = true
        } catch (e: Exception) {
            display.text = "Error"
        }
    }

    private fun calculatePercentage() {
        try {
            val currentText = display.text.toString()
            val expression = ExpressionBuilder(currentText).build()
            val value = expression.evaluate()
            val percentage = value / 100.0

            val resultText = if (percentage % 1.0 == 0.0) {
                percentage.toLong().toString()
            } else {
                percentage.toString()
            }
            display.text = resultText
            lastPressedEquals = true
        } catch (e: Exception) {
            display.text = "Error"
        }
    }
}
