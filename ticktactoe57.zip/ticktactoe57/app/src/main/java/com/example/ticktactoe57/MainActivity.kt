package com.example.ticktactoe57

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var buttons: Array<Array<Button>>
    private var playerXTurn = true
    private var moveCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize button grid (3x3)
        buttons = arrayOf(
            arrayOf(findViewById(R.id.button1), findViewById(R.id.button2), findViewById(R.id.button3)),
            arrayOf(findViewById(R.id.button4), findViewById(R.id.button5), findViewById(R.id.button6)),
            arrayOf(findViewById(R.id.button7), findViewById(R.id.button8), findViewById(R.id.button9))
        )

        setButtonListeners()
    }

    private fun setButtonListeners() {
        for (i in 0..2) {
            for (j in 0..2) {
                buttons[i][j].setOnClickListener {
                    // Prevent overwriting a filled cell
                    if (buttons[i][j].text.isNotEmpty()) return@setOnClickListener

                    // Set X or O
                    buttons[i][j].text = if (playerXTurn) "X" else "O"
                    moveCount++

                    // Check for winner
                    if (checkWinner()) {
                        val winner = if (playerXTurn) "Player X" else "Player O"
                        Toast.makeText(this, "$winner wins!", Toast.LENGTH_SHORT).show()
                        resetBoard()
                        return@setOnClickListener
                    }

                    // Check for draw
                    if (moveCount == 9) {
                        Toast.makeText(this, "It's a draw!", Toast.LENGTH_SHORT).show()
                        resetBoard()
                        return@setOnClickListener
                    }

                    // Switch turn
                    playerXTurn = !playerXTurn
                }
            }
        }
    }

    private fun checkWinner(): Boolean {
        val board = Array(3) { row ->
            Array(3) { col -> buttons[row][col].text.toString() }
        }

        // Check rows and columns
        for (i in 0..2) {
            if (board[i][0].isNotEmpty() &&
                board[i][0] == board[i][1] && board[i][1] == board[i][2]
            ) return true

            if (board[0][i].isNotEmpty() &&
                board[0][i] == board[1][i] && board[1][i] == board[2][i]
            ) return true
        }

        // Check diagonals
        if (board[0][0].isNotEmpty() &&
            board[0][0] == board[1][1] && board[1][1] == board[2][2]
        ) return true

        if (board[0][2].isNotEmpty() &&
            board[0][2] == board[1][1] && board[1][1] == board[2][0]
        ) return true

        return false
    }

    private fun resetBoard() {
        for (i in 0..2) {
            for (j in 0..2) {
                buttons[i][j].text = ""
            }
        }
        playerXTurn = true
        moveCount = 0
    }
}
